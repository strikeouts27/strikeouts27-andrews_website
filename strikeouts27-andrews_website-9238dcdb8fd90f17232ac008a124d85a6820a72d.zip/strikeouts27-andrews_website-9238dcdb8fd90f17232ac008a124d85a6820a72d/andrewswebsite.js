let person = prompt("Please enter your name", "Please enter your name");

if (person != null) {
  "Hello" + person + "! How are you today?";
}

alert("Hello " + person + ",  Welcome to my developer page!");
